package HttpSessionListener;

import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;
import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;


@WebListener
public class OnlineUserListener implements ServletContextListener, HttpSessionListener {
	//khai bao
	ServletContext application;
    public OnlineUserListener() {
        // TODO Auto-generated constructor stub
    }

	
    public void sessionCreated(HttpSessionEvent se)  { 
        Long onlineUsers = (Long) application.getAttribute("OnlineUsers");
        if(onlineUsers == null) {
        	onlineUsers = 0L;
        }
        onlineUsers ++;
        System.out.println("Session Created");
        application.setAttribute("OnlineUsers", onlineUsers);
    }

	
    public void sessionDestroyed(HttpSessionEvent se)  { 
    	 Long onlineUsers = (Long) application.getAttribute("OnlineUsers");
         if(onlineUsers == null) {
         	onlineUsers = 0L;
         }
         onlineUsers --;
         System.out.println("Session Destroyed");
         application.setAttribute("OnlineUsers", onlineUsers);
    }

	
    public void contextDestroyed(ServletContextEvent sce)  { 
         // TODO Auto-generated method stub
    	System.out.println("Context Destroyed");
    }

	
    public void contextInitialized(ServletContextEvent sce)  { 
         // TODO Auto-generated method stub
    	System.out.println("Context Initialized");
    	application = sce.getServletContext();
    }
	
}
